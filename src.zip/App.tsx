import { useState } from 'react';
import StartScreen from './screens/StartScreen';
import InstructionsScreen from './screens/InstructionsScreen';
import TestScreen from './screens/TestScreen';
import CompletionScreen from './screens/CompletionScreen';
import ResultsScreen from './screens/ResultsScreen';

type Screen = 'start' | 'instructions' | 'test' | 'completion' | 'results';

export default function App() {
  const [screen, setScreen] = useState<Screen>('start');
  const [answers, setAnswers] = useState<Record<number, number>>({});

  function handleAnswer(questionId: number, value: number) {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  }

  function handleRetake() {
    setAnswers({});
    setScreen('start');
  }

  return (
    <>
      {screen === 'start' && (
        <StartScreen onStart={() => setScreen('instructions')} />
      )}
      {screen === 'instructions' && (
        <InstructionsScreen
          onBegin={() => setScreen('test')}
          onBack={() => setScreen('start')}
        />
      )}
      {screen === 'test' && (
        <TestScreen
          answers={answers}
          onAnswer={handleAnswer}
          onComplete={() => setScreen('completion')}
        />
      )}
      {screen === 'completion' && (
        <CompletionScreen
          answeredCount={Object.keys(answers).length}
          onViewResults={() => setScreen('results')}
          onContinue={() => setScreen('test')}
        />
      )}
      {screen === 'results' && (
        <ResultsScreen
          answers={answers}
          onRetake={handleRetake}
        />
      )}
    </>
  );
}
